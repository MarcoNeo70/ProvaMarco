import UIKit

let rightGuyName = "Giovanni"
let rightGuySurname = "Monaco"
let rightGuyAge = "27"
let rightGuyNationality = "Italy"
let rightGuyCharacteristich = "glasses"
let rightGuyCompetence = "english spoken"

var boolGuy : Bool = false

var leftGuyName = "Mauro"
var leftGuyNationality = "Italy"

print ("This is my table \n")
print ("On my left there is \(leftGuyName)")
print ("On my right there is \(rightGuyName) \(rightGuySurname): he is \(rightGuyAge)")
print ("\(rightGuyName) wears \(rightGuyCharacteristich) and he is an \(rightGuyCompetence)")

print ("\(leftGuyName) is from \(leftGuyNationality), \(rightGuyName) is from \(rightGuyNationality) so...")

//((rightGuyNationality == "Italy") && (leftGuyNationality == "Italy")) ? print ("... I'm lucky!") : print ("... I have to cook!")

((rightGuyNationality == "Italy") && (leftGuyNationality == "Italy")) ? (boolGuy = true) : (boolGuy = false)

if (boolGuy) {
    print ("... I'm lucky!")
} else {
    print ("... I have to cook!")
}

//let response = readLine()
//var intNumber = Int(response!)
//print ("You say: \(intNumber))")

//if cond then {
//
//}
//else if secondCond {
//
//} else {
//}

// ternary operator -> condition ? trueValue : falseValue

// for day in 1 ... 5 {
//}

//Scope: variables created in a block, live in that block
